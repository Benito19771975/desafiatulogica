package retos;

public class Reto1 {

	public static void main(String[] args) {
		int entero=10;// variable  con valor 10
		do {
			
				
				System.out.println( entero );
				entero-- ;	// contador que resta cada vez 1
		}
		while (entero >=1 ) ;// se repite la operación hasta que la variable es igual a 1
		System.out.println("Fin del programa");
	}

}